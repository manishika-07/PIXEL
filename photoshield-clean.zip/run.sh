#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
echo "=== PhotoShield launcher ==="

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 not found. Install it from https://www.python.org/downloads/"
  exit 1
fi

[ -d .venv ] || { echo "Creating virtual environment..."; python3 -m venv .venv; }
source .venv/bin/activate

echo "Installing requirements (first run takes a minute)..."
pip install -q -r requirements.txt || { echo "Install failed. Try Python 3.10-3.12."; exit 1; }

echo "Starting server... your browser will open automatically."
( sleep 3; (open http://localhost:8000 || xdg-open http://localhost:8000) >/dev/null 2>&1 ) &
python -m uvicorn main:app --reload
