#!/usr/bin/env python3
"""
test_api.py — End-to-end smoke tests for PhotoShield API.
Generates a synthetic image in memory; never reads from disk.
Run after starting the server:
    uvicorn main:app --reload &
    python test_api.py
"""

import io
import sys
import hashlib
import json
import time

import requests
from PIL import Image, ImageDraw

BASE = "http://localhost:8000"
CLIENT_ID = "test-client-pytest-001"
HEADERS = {"X-Client-Id": CLIENT_ID}

PASS = "\033[32m✔\033[0m"
FAIL = "\033[31m✘\033[0m"
_failures = []


def check(name: str, condition: bool, detail: str = ""):
    if condition:
        print(f"  {PASS}  {name}")
    else:
        print(f"  {FAIL}  {name}  {detail}")
        _failures.append(name)


def make_test_image(width=200, height=200, fmt="PNG") -> bytes:
    """Create a colourful synthetic image with no EXIF data."""
    img = Image.new("RGB", (width, height), color=(120, 60, 180))
    draw = ImageDraw.Draw(img)
    draw.rectangle([40, 40, 160, 160], fill=(255, 200, 50))
    draw.ellipse([70, 70, 130, 130], fill=(220, 50, 90))
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return buf.getvalue()


def section(title: str):
    print(f"\n{'─'*50}\n  {title}\n{'─'*50}")


# ════════════════════════════════════════════════════════════
# Wait for server
# ════════════════════════════════════════════════════════════

def wait_for_server(max_wait=15):
    print(f"Waiting for server at {BASE} ...")
    for _ in range(max_wait):
        try:
            requests.get(f"{BASE}/api/stats", headers=HEADERS, timeout=2)
            print("Server is up.\n")
            return
        except Exception:
            time.sleep(1)
    print("Server not reachable after timeout — aborting.")
    sys.exit(1)


# ════════════════════════════════════════════════════════════
# Phase 1 — Protect & Scan
# ════════════════════════════════════════════════════════════

def test_phase1():
    section("Phase 1 — Protect a photo")
    img_bytes = make_test_image()

    # --- /api/protect ---
    r = requests.post(
        f"{BASE}/api/protect",
        headers=HEADERS,
        files={"image": ("test.png", img_bytes, "image/png")},
        data={"strip_metadata": "true", "shield_strength": "medium", "watermark_text": "PHOTOSHIELD"},
    )
    check("POST /api/protect → 200", r.status_code == 200, r.text[:200])
    check("Response is PNG bytes", r.headers.get("content-type", "").startswith("image/png"))
    check("X-Sha256 header present", "x-sha256" in r.headers)
    check("X-Phash header present", "x-phash" in r.headers)
    prot = r.headers.get("x-protections-applied", "")
    check("Protections-Applied contains metadata_stripped", "metadata_stripped" in prot)
    check("Protections-Applied contains shield_medium", "shield_medium" in prot)
    check("Protections-Applied contains watermark", "watermark" in prot)

    # bad strength
    r2 = requests.post(
        f"{BASE}/api/protect",
        headers=HEADERS,
        files={"image": ("test.png", img_bytes, "image/png")},
        data={"shield_strength": "ultra"},
    )
    check("POST /api/protect bad strength → 400", r2.status_code == 400)

    # oversized file simulation (send wrong content-length is tricky; check 10 MB limit message)
    # Instead test a non-image file
    r3 = requests.post(
        f"{BASE}/api/protect",
        headers=HEADERS,
        files={"image": ("bad.txt", b"not an image", "text/plain")},
    )
    check("POST /api/protect non-image → 400", r3.status_code == 400)

    # --- /api/scan-metadata ---
    section("Phase 1 — Scan metadata")
    r = requests.post(
        f"{BASE}/api/scan-metadata",
        files={"image": ("test.png", img_bytes, "image/png")},
    )
    check("POST /api/scan-metadata → 200", r.status_code == 200)
    body = r.json()
    check("Response has 'found' list", isinstance(body.get("found"), list))
    check("Response has 'has_gps' bool", isinstance(body.get("has_gps"), bool))


# ════════════════════════════════════════════════════════════
# Phase 2 — Fingerprints
# ════════════════════════════════════════════════════════════

def test_phase2():
    section("Phase 2 — Fingerprints")
    img_bytes = make_test_image()

    # Register fingerprint
    r = requests.post(
        f"{BASE}/api/fingerprints",
        headers=HEADERS,
        files={"image": ("test.png", img_bytes, "image/png")},
        data={"label": "My test photo"},
    )
    check("POST /api/fingerprints → 200", r.status_code == 200)
    fp = r.json()
    fp_id = fp.get("id")
    check("Record has id", fp_id is not None)
    check("Record has sha256", bool(fp.get("sha256")))
    check("Record has phash", bool(fp.get("phash")))
    check("Record has dhash", bool(fp.get("dhash")))

    # List
    r = requests.get(f"{BASE}/api/fingerprints", headers=HEADERS)
    check("GET /api/fingerprints → 200", r.status_code == 200)
    check("List contains our record", any(f["id"] == fp_id for f in r.json()))

    # Compare — exact match
    r = requests.post(
        f"{BASE}/api/fingerprints/compare",
        headers=HEADERS,
        files={"image": ("test.png", img_bytes, "image/png")},
    )
    check("POST /api/fingerprints/compare → 200", r.status_code == 200)
    result = r.json()
    check("Compare exact_match=True for same image", result.get("exact_match") is True)
    check("Compare matched=True", result.get("matched") is True)

    # Delete
    r = requests.delete(f"{BASE}/api/fingerprints/{fp_id}", headers=HEADERS)
    check(f"DELETE /api/fingerprints/{fp_id} → 200", r.status_code == 200)
    check("Deleted=True in response", r.json().get("deleted") is True)

    # 404 on re-delete
    r = requests.delete(f"{BASE}/api/fingerprints/{fp_id}", headers=HEADERS)
    check("DELETE non-existent → 404", r.status_code == 404)


# ════════════════════════════════════════════════════════════
# Phase 3 — Incidents & Response Kit
# ════════════════════════════════════════════════════════════

def test_phase3():
    section("Phase 3 — Incidents")

    # Create
    r = requests.post(
        f"{BASE}/api/incidents",
        headers={**HEADERS, "Content-Type": "application/json"},
        json={
            "platform": "instagram",
            "url": "https://instagram.com/p/example",
            "date_noticed": "2025-01-01",
            "description": "My photo shared without consent.",
            "status": "open",
        },
    )
    check("POST /api/incidents → 201", r.status_code == 201)
    inc = r.json()
    inc_id = inc.get("id")
    check("Incident has id", inc_id is not None)
    check("Incident status=open", inc.get("status") == "open")

    # Bad status
    r2 = requests.post(
        f"{BASE}/api/incidents",
        headers={**HEADERS, "Content-Type": "application/json"},
        json={"platform": "x", "status": "deleted"},
    )
    check("POST bad status → 400", r2.status_code == 400)

    # List
    r = requests.get(f"{BASE}/api/incidents", headers=HEADERS)
    check("GET /api/incidents → 200", r.status_code == 200)
    check("List has our incident", any(i["id"] == inc_id for i in r.json()))

    # Get single
    r = requests.get(f"{BASE}/api/incidents/{inc_id}", headers=HEADERS)
    check(f"GET /api/incidents/{inc_id} → 200", r.status_code == 200)

    # Patch
    r = requests.patch(
        f"{BASE}/api/incidents/{inc_id}",
        headers={**HEADERS, "Content-Type": "application/json"},
        json={"status": "reported"},
    )
    check("PATCH /api/incidents → 200", r.status_code == 200)
    check("Status updated to reported", r.json().get("status") == "reported")

    # Delete
    r = requests.delete(f"{BASE}/api/incidents/{inc_id}", headers=HEADERS)
    check("DELETE /api/incidents → 200", r.status_code == 200)

    # Response kit
    section("Phase 3 — Response Kit")
    for platform in ["instagram", "facebook", "x", "whatsapp", "other"]:
        r = requests.get(f"{BASE}/api/response-kit?platform={platform}")
        check(f"GET /api/response-kit?platform={platform} → 200", r.status_code == 200)
        body = r.json()
        check(f"  Has steps list", isinstance(body.get("steps"), list))
        check(f"  Has takedown_template", isinstance(body.get("takedown_template"), str))

    r = requests.get(f"{BASE}/api/response-kit?platform=tiktok")
    check("GET /api/response-kit bad platform → 400", r.status_code == 400)


# ════════════════════════════════════════════════════════════
# Phase 4 — Stats & Checklist
# ════════════════════════════════════════════════════════════

def test_phase4():
    section("Phase 4 — Stats")
    r = requests.get(f"{BASE}/api/stats", headers=HEADERS)
    check("GET /api/stats → 200", r.status_code == 200)
    body = r.json()
    check("Has reencoded_copies", "reencoded_copies" in body)
    check("Has fingerprints", "fingerprints" in body)
    check("Has incident_notes", "incident_notes" in body)

    section("Phase 4 — Checklist")
    r = requests.get(f"{BASE}/api/checklist", headers=HEADERS)
    check("GET /api/checklist → 200", r.status_code == 200)

    r = requests.put(
        f"{BASE}/api/checklist",
        headers={**HEADERS, "Content-Type": "application/json"},
        json={"metadata_stripped": True, "watermark_added": False, "shield_applied": True},
    )
    check("PUT /api/checklist → 200", r.status_code == 200)
    body = r.json()
    check("metadata_stripped=True", body.get("metadata_stripped") is True)
    check("shield_applied=True", body.get("shield_applied") is True)
    check("watermark_added=False", body.get("watermark_added") is False)


# ════════════════════════════════════════════════════════════
# Frontend static
# ════════════════════════════════════════════════════════════

def test_static():
    section("Static frontend")
    r = requests.get(f"{BASE}/")
    check("GET / → 200 (index.html served)", r.status_code == 200)
    r2 = requests.get(f"{BASE}/api.js")
    check("GET /api.js → 200", r2.status_code == 200)


# ════════════════════════════════════════════════════════════
# Main
# ════════════════════════════════════════════════════════════

if __name__ == "__main__":
    wait_for_server()
    test_static()
    test_phase1()
    test_phase2()
    test_phase3()
    test_phase4()

    print(f"\n{'═'*50}")
    if _failures:
        print(f"  \033[31m{len(_failures)} test(s) FAILED:\033[0m")
        for f in _failures:
            print(f"    • {f}")
        sys.exit(1)
    else:
        print(f"  \033[32mAll tests passed!\033[0m")
