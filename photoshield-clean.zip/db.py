# db.py — SQLite helpers. All tables created on first import.
import sqlite3
import contextlib
from pathlib import Path

DB_PATH = Path(__file__).parent / "photoshield.db"


def _connect() -> sqlite3.Connection:
    """Return a connection with row_factory set to Row."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")  # safe for concurrent reads
    return conn


@contextlib.contextmanager
def get_db():
    """Context-manager that yields a connection and commits on exit."""
    conn = _connect()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    """Create all tables if they don't exist. Called at startup."""
    with get_db() as conn:
        conn.executescript("""
            -- Tracks how many re-encoded copies per client
            CREATE TABLE IF NOT EXISTS counters (
                client_id       TEXT PRIMARY KEY,
                reencoded_copies INTEGER NOT NULL DEFAULT 0
            );

            -- Perceptual fingerprints stored per client
            CREATE TABLE IF NOT EXISTS fingerprints (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id   TEXT    NOT NULL,
                label       TEXT    NOT NULL,
                sha256      TEXT    NOT NULL,
                phash       TEXT    NOT NULL,
                dhash       TEXT    NOT NULL,
                created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
            );

            -- Incident log
            CREATE TABLE IF NOT EXISTS incidents (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id     TEXT NOT NULL,
                platform      TEXT NOT NULL,
                url           TEXT,
                date_noticed  TEXT,
                description   TEXT,
                status        TEXT NOT NULL DEFAULT 'open',
                created_at    TEXT NOT NULL DEFAULT (datetime('now'))
            );

            -- "Before you post" checklist (3 boolean items per client)
            CREATE TABLE IF NOT EXISTS checklist (
                client_id       TEXT PRIMARY KEY,
                metadata_stripped INTEGER NOT NULL DEFAULT 0,
                watermark_added   INTEGER NOT NULL DEFAULT 0,
                shield_applied    INTEGER NOT NULL DEFAULT 0
            );
        """)


# ── Counter helpers ──────────────────────────────────────────────────────────

def increment_reencoded(conn: sqlite3.Connection, client_id: str) -> None:
    """Upsert the reencoded_copies counter for a client."""
    conn.execute("""
        INSERT INTO counters (client_id, reencoded_copies)
        VALUES (?, 1)
        ON CONFLICT(client_id) DO UPDATE SET reencoded_copies = reencoded_copies + 1
    """, (client_id,))


def get_counters(conn: sqlite3.Connection, client_id: str) -> dict:
    row = conn.execute(
        "SELECT reencoded_copies FROM counters WHERE client_id = ?", (client_id,)
    ).fetchone()
    return {"reencoded_copies": row["reencoded_copies"] if row else 0}


# ── Fingerprint helpers ──────────────────────────────────────────────────────

def insert_fingerprint(conn, client_id, label, sha256, phash, dhash) -> dict:
    cur = conn.execute("""
        INSERT INTO fingerprints (client_id, label, sha256, phash, dhash)
        VALUES (?, ?, ?, ?, ?)
    """, (client_id, label, sha256, phash, dhash))
    row = conn.execute(
        "SELECT * FROM fingerprints WHERE id = ?", (cur.lastrowid,)
    ).fetchone()
    return dict(row)


def list_fingerprints(conn, client_id) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM fingerprints WHERE client_id = ? ORDER BY created_at DESC",
        (client_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def delete_fingerprint(conn, client_id, fp_id) -> bool:
    cur = conn.execute(
        "DELETE FROM fingerprints WHERE id = ? AND client_id = ?", (fp_id, client_id)
    )
    return cur.rowcount > 0


# ── Incident helpers ─────────────────────────────────────────────────────────

def insert_incident(conn, client_id, platform, url, date_noticed, description, status) -> dict:
    cur = conn.execute("""
        INSERT INTO incidents (client_id, platform, url, date_noticed, description, status)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (client_id, platform, url, date_noticed, description, status))
    row = conn.execute(
        "SELECT * FROM incidents WHERE id = ?", (cur.lastrowid,)
    ).fetchone()
    return dict(row)


def list_incidents(conn, client_id) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM incidents WHERE client_id = ? ORDER BY created_at DESC",
        (client_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def get_incident(conn, client_id, inc_id) -> dict | None:
    row = conn.execute(
        "SELECT * FROM incidents WHERE id = ? AND client_id = ?", (inc_id, client_id)
    ).fetchone()
    return dict(row) if row else None


def update_incident(conn, client_id, inc_id, **fields) -> dict | None:
    if not fields:
        return get_incident(conn, client_id, inc_id)
    sets = ", ".join(f"{k} = ?" for k in fields)
    vals = list(fields.values()) + [inc_id, client_id]
    conn.execute(
        f"UPDATE incidents SET {sets} WHERE id = ? AND client_id = ?", vals
    )
    return get_incident(conn, client_id, inc_id)


def delete_incident(conn, client_id, inc_id) -> bool:
    cur = conn.execute(
        "DELETE FROM incidents WHERE id = ? AND client_id = ?", (inc_id, client_id)
    )
    return cur.rowcount > 0


# ── Checklist helpers ────────────────────────────────────────────────────────

def get_checklist(conn, client_id) -> dict:
    row = conn.execute(
        "SELECT * FROM checklist WHERE client_id = ?", (client_id,)
    ).fetchone()
    if row:
        return {
            "metadata_stripped": bool(row["metadata_stripped"]),
            "watermark_added":   bool(row["watermark_added"]),
            "shield_applied":    bool(row["shield_applied"]),
        }
    return {"metadata_stripped": False, "watermark_added": False, "shield_applied": False}


def set_checklist(conn, client_id, metadata_stripped, watermark_added, shield_applied) -> dict:
    conn.execute("""
        INSERT INTO checklist (client_id, metadata_stripped, watermark_added, shield_applied)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(client_id) DO UPDATE SET
            metadata_stripped = excluded.metadata_stripped,
            watermark_added   = excluded.watermark_added,
            shield_applied    = excluded.shield_applied
    """, (client_id, int(metadata_stripped), int(watermark_added), int(shield_applied)))
    return get_checklist(conn, client_id)


# ── Stats helper ─────────────────────────────────────────────────────────────

def get_stats(conn, client_id) -> dict:
    counters = get_counters(conn, client_id)
    fp_count = conn.execute(
        "SELECT COUNT(*) FROM fingerprints WHERE client_id = ?", (client_id,)
    ).fetchone()[0]
    inc_count = conn.execute(
        "SELECT COUNT(*) FROM incidents WHERE client_id = ?", (client_id,)
    ).fetchone()[0]
    return {
        "reencoded_copies": counters["reencoded_copies"],
        "fingerprints":     fp_count,
        "incident_notes":   inc_count,
    }
