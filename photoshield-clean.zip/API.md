# PhotoShield API Reference

Base URL: `http://localhost:8000`  
All endpoints that scope data by user require the header **`X-Client-Id: <your-id>`**.  
The frontend auto-generates this in `localStorage` via `api.js → getClientId()`.

---

## Common Error Format

```json
{ "detail": "Human-readable error message." }
```

| Code | Meaning |
|------|---------|
| 400  | Bad request (validation error) |
| 404  | Resource not found |
| 413  | File too large (> 10 MB) |
| 422  | Missing required field |

---

## Phase 1 — Protect a Photo

### `POST /api/protect`

Protect an image: strip EXIF, add shield noise, optionally watermark.  
Returns the processed image as a **PNG binary**.

**Request** — `multipart/form-data`

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| `image` | file | required | JPEG / PNG / WEBP, max 10 MB |
| `strip_metadata` | bool | `true` | Strip EXIF from result |
| `shield_strength` | string | `medium` | `low` / `medium` / `high` |
| `watermark_text` | string | `""` | Leave empty to skip watermark |

**Response** — `200 image/png` (binary PNG bytes)

| Header | Example | Notes |
|--------|---------|-------|
| `X-Sha256` | `abc123...` | SHA-256 of the output PNG |
| `X-Phash` | `f8c4a2...` | Perceptual hash |
| `X-Protections-Applied` | `metadata_stripped,shield_medium,watermark` | Comma list of what was actually done |

**Example `api.js` call:**
```js
const result = await protectPhoto(fileInput.files[0], {
  shieldStrength: "high",
  watermarkText: "© Me 2025",
});
if (result.ok) {
  const url = URL.createObjectURL(result.data); // result.data is a Blob
  document.getElementById("output-img").src = url;
  console.log("Protections applied:", result.protections);
}
```

---

### `POST /api/scan-metadata`

Scan EXIF data in an image. **Nothing is stored.**

**Request** — `multipart/form-data`

| Field | Type | Notes |
|-------|------|-------|
| `image` | file | JPEG / PNG / WEBP, max 10 MB |

**Response** — `200 application/json`

```json
{
  "found": [
    { "field": "GPSInfo", "value": { "GPSLatitude": "...", "GPSLongitude": "..." } },
    { "field": "Model", "value": "iPhone 14 Pro" },
    { "field": "DateTime", "value": "2024:08:12 14:33:00" }
  ],
  "has_gps": true
}
```

**Example `api.js` call:**
```js
const result = await scanMetadata(fileInput.files[0]);
if (result.ok && result.data.has_gps) {
  showWarning("⚠️ This photo contains GPS location data!");
}
```

---

## Phase 2 — Watch & Fingerprints

### `POST /api/fingerprints`

Register a fingerprint (hashes only — image never stored).

**Request** — `multipart/form-data`

| Field | Type | Notes |
|-------|------|-------|
| `image` | file | Required |
| `label` | string | Required, e.g. `"Profile pic Jan 2025"` |

**Response** — `200 application/json`

```json
{
  "id": 1,
  "client_id": "...",
  "label": "Profile pic Jan 2025",
  "sha256": "abc...",
  "phash": "f8c4...",
  "dhash": "1a2b...",
  "created_at": "2025-01-15 12:00:00"
}
```

---

### `GET /api/fingerprints`

List all fingerprints for this client.

**Response** — `200 application/json` — array of fingerprint objects (same shape as above)

---

### `DELETE /api/fingerprints/{id}`

Delete a fingerprint.

**Response** — `200 application/json`
```json
{ "deleted": true, "id": 1 }
```

---

### `POST /api/fingerprints/compare`

Compare an uploaded image against all stored fingerprints.  
Hamming distance ≤ 10 = likely same photo (resized / cropped / recompressed).

**Request** — `multipart/form-data`

| Field | Type | Notes |
|-------|------|-------|
| `image` | file | Required |

**Response** — `200 application/json`

```json
{
  "matched": true,
  "label": "Profile pic Jan 2025",
  "exact_match": false,
  "hamming_distance": 4,
  "similarity_percent": 93.8
}
```

If no fingerprints are stored: `matched: false`, all other fields `null`.

**Example `api.js` call:**
```js
const result = await compareFingerprint(suspectFile);
if (result.ok && result.data.matched) {
  alert(`⚠️ Possible match: "${result.data.label}" (${result.data.similarity_percent}% similar)`);
}
```

---

## Phase 3 — Incidents & Response Kit

### `POST /api/incidents` → `201`

Create an incident note.

**Request** — `application/json`

```json
{
  "platform":     "instagram",
  "url":          "https://instagram.com/p/abc",
  "date_noticed": "2025-01-15",
  "description":  "Photo shared without my consent.",
  "status":       "open"
}
```

`platform` is required. `status` must be `open` / `reported` / `resolved` (default `open`).

**Response** — `201 application/json` — the created incident object

---

### `GET /api/incidents`

List all incidents.

**Response** — `200 application/json` — array of:
```json
{
  "id": 1, "client_id": "...", "platform": "instagram",
  "url": "...", "date_noticed": "...", "description": "...",
  "status": "open", "created_at": "2025-01-15 12:00:00"
}
```

---

### `GET /api/incidents/{id}`

Get a single incident. Returns `404` if not found.

---

### `PATCH /api/incidents/{id}`

Partial update. Send only the fields you want to change.

**Request** — `application/json`
```json
{ "status": "reported" }
```

---

### `DELETE /api/incidents/{id}`

Delete an incident.

**Response** — `200 application/json`
```json
{ "deleted": true, "id": 1 }
```

---

### `GET /api/response-kit?platform=<platform>`

Get platform-specific reporting guide, takedown template, and helplines.

**Query param** — `platform`: `instagram` | `facebook` | `x` | `whatsapp` | `other`

**Response** — `200 application/json`

```json
{
  "steps": ["Take a screenshot...", "Tap the three-dot menu..."],
  "takedown_template": "Subject: Urgent Takedown...\n\nDear ...",
  "links": [
    { "label": "Instagram Help", "url": "https://...", "verify_before_launch": true }
  ],
  "helplines": [
    { "label": "Cyber Crime Portal", "url": "https://cybercrime.gov.in", "phone": "1930", "verify_before_launch": true }
  ]
}
```

> ⚠️ All `helplines` and `links` entries with `verify_before_launch: true` **must be verified** before the app goes live. Phone numbers and URLs change.

**Example `api.js` call:**
```js
const result = await getResponseKit("instagram");
if (result.ok) {
  result.data.steps.forEach((step, i) => {
    document.getElementById("steps").innerHTML += `<li>${step}</li>`;
  });
}
```

---

## Phase 4 — Overview & Checklist

### `GET /api/stats`

Usage summary for the current client.

**Response** — `200 application/json`
```json
{
  "reencoded_copies": 5,
  "fingerprints": 3,
  "incident_notes": 2
}
```

---

### `GET /api/checklist`

Get "Before you post" checklist state.

**Response** — `200 application/json`
```json
{
  "metadata_stripped": true,
  "watermark_added": false,
  "shield_applied": true
}
```

---

### `PUT /api/checklist`

Update all three checklist items. Missing keys default to `false`.

**Request** — `application/json`
```json
{
  "metadata_stripped": true,
  "watermark_added": true,
  "shield_applied": false
}
```

**Response** — `200 application/json` — same shape as GET

**Example `api.js` call:**
```js
// When user ticks "Metadata stripped" checkbox:
await setChecklist({ metadata_stripped: true, watermark_added: false, shield_applied: false });
```

---

## Wiring Checklist for the Frontend

| Section | Action | Helper |
|---------|--------|--------|
| Overview | Load stats on page load | `getStats()` |
| Overview | Load + save checklist | `getChecklist()` / `setChecklist()` |
| Protect a photo | Submit button | `protectPhoto(file, opts)` |
| Protect a photo | "What does my photo reveal?" | `scanMetadata(file)` |
| Watch & fingerprints | Register fingerprint | `addFingerprint(file, label)` |
| Watch & fingerprints | List / delete fingerprints | `listFingerprints()` / `deleteFingerprint(id)` |
| Watch & fingerprints | Reverse image search | `compareFingerprint(file)` |
| Incident notes | CRUD form | `createIncident` / `updateIncident` / `deleteIncident` |
| Response Kit | Platform dropdown | `getResponseKit(platform)` |
