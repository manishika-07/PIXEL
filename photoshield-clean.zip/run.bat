@echo off
cd /d "%~dp0"
echo === PhotoShield launcher ===

set PY=python
where python >nul 2>nul || set PY=py
where %PY% >nul 2>nul || (
  echo Python was not found. Install it from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH" during setup. Then double-click this file again.
  pause
  exit /b 1
)

if not exist .venv (
  echo Creating virtual environment...
  %PY% -m venv .venv
)
call .venv\Scripts\activate

echo Installing requirements (first run takes a minute)...
pip install -q -r requirements.txt
if errorlevel 1 (
  echo.
  echo Install failed. Try Python 3.10, 3.11 or 3.12.
  pause
  exit /b 1
)

echo Starting server... your browser will open automatically.
start "" cmd /c "timeout /t 4 >nul & start http://localhost:8000"
python -m uvicorn main:app --reload
pause
